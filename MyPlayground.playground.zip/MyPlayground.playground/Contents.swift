import UIKit

var greeting = "Hello, playground"
var mobileBrand = "Apple"
mobileBrand = "redmi"
print(mobileBrand)
var pi = 3.14
print(Pi)
let Pi = 3.14
print(pi)
var age : Double = 23.2
age = age * 2.7
print(age)
var aweMessage = "This is Superb!"
print(aweMessage)
print("aweMessage")
var course1 = "iOS"
var course2 = "Java"
print(course1,course2)
print(course1,"-",course2)
print(10,20,30)
    print(12.5,15.5)
var httpError  = (errorCode : 404  , errorMessage : "PageNotFound")
print(httpError)
print(httpError.errorCode , terminator : ": ")
print(httpError.errorMessage )
var name = ("John","Smith")
var fName = name.1
var lName = name.1
print(fName , terminator : ",")
print(lName)
var origin = (x : 0 , y : 0)
var point = origin
print(point)
let city = (name : "Maryville" , population : 11,000)
let ( cityName ,cityPopulation ) = (city.0 , city.1 )
print(cityName)
print(cityPopulation)
print(type(of: city))
let groceries = ("bread","onions")
print(groceries.0)
print(groceries.1)
print(type(of: groceries))
var fname = "Joe"
var lname = "Root"

print("First Name is \(fname) and Last Name is \(lname)")
var cricketKit = ("handGloves" ,"helmet",("bat","ball"))
print(cricketKit.0)
print(cricketKit.1)
print(cricketKit.2.0)
print(cricketKit.2.1)
print(cricketKit.2)
var  firstNumber : Int = 40
var secondNumber : Int = 20
print(secondNumber / firstNumber)
var four = 4
var finalNumber = "one"
print(finalNumber)
var number1 = (4,5)
var number2 = (4,5)
print(number1 <  number2)
print(4 > 5 || 8 > 3) 
